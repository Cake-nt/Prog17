﻿namespace Calculator__Project_9_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            divideBtn = new Button();
            subtractBtn = new Button();
            btn3 = new Button();
            btn2 = new Button();
            btn1 = new Button();
            addBtn = new Button();
            equalsBtn = new Button();
            periodBtn = new Button();
            btn0 = new Button();
            multiplyBtn = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn4 = new Button();
            resultBox = new TextBox();
            clearBtn = new Button();
            SuspendLayout();
            // 
            // btn7
            // 
            btn7.BackColor = Color.Snow;
            btn7.Font = new Font("Segoe UI", 14.25F);
            btn7.Location = new Point(176, 162);
            btn7.Name = "btn7";
            btn7.Size = new Size(181, 88);
            btn7.TabIndex = 0;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = false;
            btn7.Click += click_button;
            // 
            // btn8
            // 
            btn8.BackColor = Color.Snow;
            btn8.Font = new Font("Segoe UI", 14.25F);
            btn8.Location = new Point(440, 162);
            btn8.Name = "btn8";
            btn8.Size = new Size(181, 88);
            btn8.TabIndex = 1;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = false;
            btn8.Click += click_button;
            // 
            // btn9
            // 
            btn9.BackColor = Color.Snow;
            btn9.Font = new Font("Segoe UI", 14.25F);
            btn9.Location = new Point(693, 162);
            btn9.Name = "btn9";
            btn9.Size = new Size(181, 88);
            btn9.TabIndex = 2;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = false;
            btn9.Click += click_button;
            // 
            // divideBtn
            // 
            divideBtn.BackColor = Color.DarkGreen;
            divideBtn.Font = new Font("Segoe UI", 14.25F);
            divideBtn.Location = new Point(958, 162);
            divideBtn.Name = "divideBtn";
            divideBtn.Size = new Size(181, 88);
            divideBtn.TabIndex = 3;
            divideBtn.Text = "÷";
            divideBtn.UseVisualStyleBackColor = false;
            divideBtn.Click += operator_click;
            // 
            // subtractBtn
            // 
            subtractBtn.BackColor = Color.DarkGreen;
            subtractBtn.Font = new Font("Segoe UI", 14.25F);
            subtractBtn.Location = new Point(955, 385);
            subtractBtn.Name = "subtractBtn";
            subtractBtn.Size = new Size(181, 88);
            subtractBtn.TabIndex = 7;
            subtractBtn.Text = "-";
            subtractBtn.UseVisualStyleBackColor = false;
            subtractBtn.Click += operator_click;
            // 
            // btn3
            // 
            btn3.BackColor = Color.Snow;
            btn3.Font = new Font("Segoe UI", 14.25F);
            btn3.Location = new Point(690, 385);
            btn3.Name = "btn3";
            btn3.Size = new Size(181, 88);
            btn3.TabIndex = 6;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = false;
            btn3.Click += click_button;
            // 
            // btn2
            // 
            btn2.BackColor = Color.Snow;
            btn2.Font = new Font("Segoe UI", 14.25F);
            btn2.Location = new Point(437, 385);
            btn2.Name = "btn2";
            btn2.Size = new Size(181, 88);
            btn2.TabIndex = 5;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = false;
            btn2.Click += click_button;
            // 
            // btn1
            // 
            btn1.BackColor = Color.Snow;
            btn1.Font = new Font("Segoe UI", 14.25F);
            btn1.Location = new Point(173, 385);
            btn1.Name = "btn1";
            btn1.Size = new Size(181, 88);
            btn1.TabIndex = 4;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = false;
            btn1.Click += click_button;
            // 
            // addBtn
            // 
            addBtn.BackColor = Color.DarkGreen;
            addBtn.Font = new Font("Segoe UI", 14.25F);
            addBtn.Location = new Point(955, 505);
            addBtn.Name = "addBtn";
            addBtn.Size = new Size(181, 88);
            addBtn.TabIndex = 11;
            addBtn.Text = "+";
            addBtn.UseVisualStyleBackColor = false;
            addBtn.Click += operator_click;
            // 
            // equalsBtn
            // 
            equalsBtn.BackColor = Color.Snow;
            equalsBtn.Font = new Font("Segoe UI", 14.25F);
            equalsBtn.Location = new Point(690, 505);
            equalsBtn.Name = "equalsBtn";
            equalsBtn.Size = new Size(181, 88);
            equalsBtn.TabIndex = 10;
            equalsBtn.Text = "=";
            equalsBtn.UseVisualStyleBackColor = false;
            equalsBtn.Click += equalBtn_Click;
            // 
            // periodBtn
            // 
            periodBtn.BackColor = Color.Snow;
            periodBtn.Font = new Font("Segoe UI", 14.25F);
            periodBtn.Location = new Point(437, 505);
            periodBtn.Name = "periodBtn";
            periodBtn.Size = new Size(181, 88);
            periodBtn.TabIndex = 9;
            periodBtn.Text = ".";
            periodBtn.UseVisualStyleBackColor = false;
            periodBtn.Click += click_button;
            // 
            // btn0
            // 
            btn0.BackColor = Color.Snow;
            btn0.Font = new Font("Segoe UI", 14.25F);
            btn0.Location = new Point(173, 505);
            btn0.Name = "btn0";
            btn0.Size = new Size(181, 88);
            btn0.TabIndex = 8;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = false;
            btn0.Click += click_button;
            // 
            // multiplyBtn
            // 
            multiplyBtn.BackColor = Color.DarkGreen;
            multiplyBtn.Font = new Font("Segoe UI", 14.25F);
            multiplyBtn.Location = new Point(955, 277);
            multiplyBtn.Name = "multiplyBtn";
            multiplyBtn.Size = new Size(181, 88);
            multiplyBtn.TabIndex = 15;
            multiplyBtn.Text = "x";
            multiplyBtn.UseVisualStyleBackColor = false;
            multiplyBtn.Click += operator_click;
            // 
            // btn6
            // 
            btn6.BackColor = Color.Snow;
            btn6.Font = new Font("Segoe UI", 14.25F);
            btn6.Location = new Point(690, 277);
            btn6.Name = "btn6";
            btn6.Size = new Size(181, 88);
            btn6.TabIndex = 14;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = false;
            btn6.Click += click_button;
            // 
            // btn5
            // 
            btn5.BackColor = Color.Snow;
            btn5.Font = new Font("Segoe UI", 14.25F);
            btn5.Location = new Point(437, 277);
            btn5.Name = "btn5";
            btn5.Size = new Size(181, 88);
            btn5.TabIndex = 13;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = false;
            btn5.Click += click_button;
            // 
            // btn4
            // 
            btn4.BackColor = Color.Snow;
            btn4.Font = new Font("Segoe UI", 14.25F);
            btn4.Location = new Point(173, 277);
            btn4.Name = "btn4";
            btn4.Size = new Size(181, 88);
            btn4.TabIndex = 12;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = false;
            btn4.Click += click_button;
            // 
            // resultBox
            // 
            resultBox.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            resultBox.Location = new Point(176, 69);
            resultBox.Multiline = true;
            resultBox.Name = "resultBox";
            resultBox.Size = new Size(966, 73);
            resultBox.TabIndex = 16;
            resultBox.Text = "0";
            resultBox.TextAlign = HorizontalAlignment.Center;
            // 
            // clearBtn
            // 
            clearBtn.BackColor = Color.Snow;
            clearBtn.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            clearBtn.Location = new Point(437, 622);
            clearBtn.Name = "clearBtn";
            clearBtn.Size = new Size(434, 88);
            clearBtn.TabIndex = 17;
            clearBtn.Text = "Clear";
            clearBtn.UseVisualStyleBackColor = false;
            clearBtn.Click += clearBtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1316, 747);
            Controls.Add(clearBtn);
            Controls.Add(resultBox);
            Controls.Add(multiplyBtn);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(addBtn);
            Controls.Add(equalsBtn);
            Controls.Add(periodBtn);
            Controls.Add(btn0);
            Controls.Add(subtractBtn);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(divideBtn);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button divideBtn;
        private Button subtractBtn;
        private Button btn3;
        private Button btn2;
        private Button btn1;
        private Button addBtn;
        private Button equalsBtn;
        private Button periodBtn;
        private Button btn0;
        private Button multiplyBtn;
        private Button btn6;
        private Button btn5;
        private Button btn4;
        private TextBox resultBox;
        private Button clearBtn;
    }
}
